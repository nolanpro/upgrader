import Vue from "vue";
import AuthClientsListing from "./components/AuthClientsListing";
Vue.component('auth-clients-listing', AuthClientsListing);