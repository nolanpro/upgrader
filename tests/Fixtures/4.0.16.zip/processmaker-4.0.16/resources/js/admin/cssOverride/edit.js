import Vue from "vue";
import ColorPicker from "./components/ColorPicker";

Vue.component('color-picker', ColorPicker);
