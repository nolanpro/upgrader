import Vue from "vue";
import UsersInGroupListing from "./components/UsersInGroupListing.vue";

Vue.component('users-in-group', UsersInGroupListing);

