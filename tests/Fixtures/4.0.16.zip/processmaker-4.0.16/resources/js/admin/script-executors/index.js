import ScriptExecutors from './ScriptExecutors';

new Vue({
    el: '#script-executors',
    components: { ScriptExecutors },
});