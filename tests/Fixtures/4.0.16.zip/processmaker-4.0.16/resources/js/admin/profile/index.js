import Vue from "vue";
import Profile from "./components/Profile";

new Vue({
    el: "#profile",
    components: {
        Profile
    }
});
