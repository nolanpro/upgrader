import Vue from "vue";
import VuePassword from "vue-password";

Vue.component("vue-password", VuePassword);
