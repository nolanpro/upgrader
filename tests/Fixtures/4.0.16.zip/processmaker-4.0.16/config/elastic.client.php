<?php declare(strict_types=1);

return [
    'hosts' => [
        env('ELASTIC_HOST', 'http://localhost:9200'),
    ]
];
