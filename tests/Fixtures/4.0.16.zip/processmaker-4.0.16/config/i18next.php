<?php

return [
    'flatten' => false,
    'exclude' => [
        'groups' => [],
    ]
];