<?php

return [
    'bootstrap-items' => 'laravel-menu::bootstrap-navbar-items',
];
