<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Script Runners
    |--------------------------------------------------------------------------
    |
    | These have been moved to executor packages. See:
    | https://github.com/ProcessMaker/docker-executor-php
    | https://github.com/ProcessMaker/docker-executor-lua
    | https://github.com/ProcessMaker/docker-executor-node
    |
    */
];
