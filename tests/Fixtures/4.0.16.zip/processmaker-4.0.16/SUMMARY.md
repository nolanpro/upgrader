# Table of contents

* [ProcessMaker 4.1 Community Edition Documentation](README.md)
* [Getting Started](getting-started/README.md)
  * [Prerequisites](getting-started/prerequisites.md)
  * [Installing Stacks](getting-started/installing-stacks.md)
  * [Install ProcessMaker On-Premise](getting-started/install-processmaker-on-premise.md)
* [Using ProcessMaker](using-processmaker.md)
* [Viewing Processes](viewing-processes.md)

