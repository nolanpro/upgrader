global.Snap = () => {
    return {}
};

global.Dispatcher = () => {
    return {}
};

global.$ = require("jquery")
global.Vue = require("vue")
global._ = require("lodash")
