<?php
namespace ProcessMaker\Http\Resources;

class ProcessCategory extends ApiResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $array = parent::toArray($request);

        return $array;
    }
}
