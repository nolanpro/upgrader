<?php

namespace ProcessMaker\Http\Controllers;

use Illuminate\Http\Request;

class QueueMonitorController extends Controller
{
    //
}
