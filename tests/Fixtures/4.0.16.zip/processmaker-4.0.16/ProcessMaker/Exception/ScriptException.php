<?php

namespace ProcessMaker\Exception;

use Exception;

/**
 * Thrown if the scripts to a process failed
 *
 * @package ProcessMaker\Exceptions
 */

class ScriptException extends Exception
{

}
