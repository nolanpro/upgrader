<?php

namespace ProcessMaker\Exception;

use Exception;

/**
 * Description of FileManagerRemoveEmailTemplateException
 *
 */
class FileManagerRemoveEmailTemplateException extends Exception
{
    
}
