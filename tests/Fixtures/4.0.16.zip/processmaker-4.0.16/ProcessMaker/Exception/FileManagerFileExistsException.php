<?php

namespace ProcessMaker\Exception;

use Exception;

/**
 * Description of FileManagerFileExistsException
 *
 */
class FileManagerFileExistsException extends Exception
{
    //put your code here
}
