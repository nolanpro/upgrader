<?php

namespace ProcessMaker\Exception;

use Exception;

/**
 * Description of FileManagerUnableToEditException
 *
 */
class FileManagerUnableToEditException extends Exception
{
    
}
