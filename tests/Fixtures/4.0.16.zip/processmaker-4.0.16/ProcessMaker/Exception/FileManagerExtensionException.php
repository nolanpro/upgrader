<?php

namespace ProcessMaker\Exception;

use Exception;

/**
 * Description of InvalidFileManagerExtension
 *
 */
class FileManagerExtensionException extends Exception
{
    
}
