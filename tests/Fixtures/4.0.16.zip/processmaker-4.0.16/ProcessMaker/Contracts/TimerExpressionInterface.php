<?php

namespace ProcessMaker\Contracts;

use ProcessMaker\Nayra\Contracts\Bpmn\FormalExpressionInterface;

interface TimerExpressionInterface extends FormalExpressionInterface
{

}
