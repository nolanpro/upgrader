---
description: >-
  Understand ProcessMaker prerequisites, and then install ProcessMaker
  on-premise.
---

# Getting Started

